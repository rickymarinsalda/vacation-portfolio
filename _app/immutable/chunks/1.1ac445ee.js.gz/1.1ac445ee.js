import{default as t}from"../entry/error.svelte.c02d1b7a.js";export{t as component};
