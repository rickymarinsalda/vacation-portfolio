import{default as t}from"../entry/error.svelte.22a94a5e.js";export{t as component};
