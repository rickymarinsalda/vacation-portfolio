import{default as t}from"../entry/_page.svelte.18a321de.js";export{t as component};
