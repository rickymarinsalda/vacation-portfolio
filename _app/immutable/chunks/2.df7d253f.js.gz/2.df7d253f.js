import{default as t}from"../entry/_page.svelte.34998ea1.js";export{t as component};
