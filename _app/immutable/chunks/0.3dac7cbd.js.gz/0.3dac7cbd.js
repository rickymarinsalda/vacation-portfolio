import{_ as r}from"./_layout.da46b06b.js";import{default as t}from"../entry/_layout.svelte.b6c4e48a.js";export{t as component,r as universal};
