import{default as t}from"../entry/error.svelte.182b1b97.js";export{t as component};
