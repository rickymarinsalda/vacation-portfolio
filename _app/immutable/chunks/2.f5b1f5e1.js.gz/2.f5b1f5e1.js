import{default as t}from"../entry/_page.svelte.88b109d4.js";export{t as component};
