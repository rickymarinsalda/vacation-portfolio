import{default as t}from"../entry/error.svelte.5e6bdb2d.js";export{t as component};
