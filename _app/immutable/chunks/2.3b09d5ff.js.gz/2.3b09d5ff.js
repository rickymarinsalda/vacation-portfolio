import{default as t}from"../entry/_page.svelte.b26f598c.js";export{t as component};
