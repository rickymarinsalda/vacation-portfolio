import{default as t}from"../entry/_page.svelte.dfdfd4c7.js";export{t as component};
