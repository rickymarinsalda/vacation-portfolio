import{default as t}from"../entry/_page.svelte.f527c667.js";export{t as component};
