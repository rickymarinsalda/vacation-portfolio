import{default as t}from"../entry/error.svelte.aa63fa45.js";export{t as component};
