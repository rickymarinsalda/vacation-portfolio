import{default as t}from"../entry/_page.svelte.10cff7d9.js";export{t as component};
