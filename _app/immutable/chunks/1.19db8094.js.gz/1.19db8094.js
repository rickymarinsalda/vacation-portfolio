import{default as t}from"../entry/error.svelte.1a397090.js";export{t as component};
