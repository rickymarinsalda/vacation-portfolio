import{default as t}from"../entry/_page.svelte.13e30b00.js";export{t as component};
