import{default as t}from"../entry/error.svelte.fc946478.js";export{t as component};
