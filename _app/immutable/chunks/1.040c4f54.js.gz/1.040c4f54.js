import{default as t}from"../entry/error.svelte.96234335.js";export{t as component};
