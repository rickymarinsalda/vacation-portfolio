import{default as t}from"../entry/error.svelte.981f7e67.js";export{t as component};
