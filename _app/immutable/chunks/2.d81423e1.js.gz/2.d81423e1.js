import{default as t}from"../entry/_page.svelte.f945718d.js";export{t as component};
