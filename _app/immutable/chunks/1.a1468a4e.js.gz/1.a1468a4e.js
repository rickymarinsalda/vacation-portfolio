import{default as t}from"../entry/error.svelte.34602256.js";export{t as component};
