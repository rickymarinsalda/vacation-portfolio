import{default as t}from"../entry/error.svelte.a7790e40.js";export{t as component};
