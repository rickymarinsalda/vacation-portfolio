import{default as t}from"../entry/_page.svelte.152fadc6.js";export{t as component};
