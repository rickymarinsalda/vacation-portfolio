import{default as t}from"../entry/error.svelte.21e97c76.js";export{t as component};
