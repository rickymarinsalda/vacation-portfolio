import{default as t}from"../entry/error.svelte.402e0fe1.js";export{t as component};
