import{default as t}from"../entry/error.svelte.d427428c.js";export{t as component};
