import{default as t}from"../entry/_page.svelte.dcb34383.js";export{t as component};
