import{default as t}from"../entry/_page.svelte.8273817c.js";export{t as component};
