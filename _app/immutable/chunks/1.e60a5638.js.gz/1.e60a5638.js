import{default as t}from"../entry/error.svelte.bc039f5d.js";export{t as component};
