import{default as t}from"../entry/error.svelte.e65e5096.js";export{t as component};
