import{default as t}from"../entry/_page.svelte.421ddad5.js";export{t as component};
