import{default as t}from"../entry/error.svelte.66ba7532.js";export{t as component};
