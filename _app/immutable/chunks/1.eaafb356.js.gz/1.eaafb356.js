import{default as t}from"../entry/error.svelte.ab5d59cf.js";export{t as component};
