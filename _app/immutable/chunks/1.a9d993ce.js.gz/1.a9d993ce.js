import{default as t}from"../entry/error.svelte.9b03df1f.js";export{t as component};
