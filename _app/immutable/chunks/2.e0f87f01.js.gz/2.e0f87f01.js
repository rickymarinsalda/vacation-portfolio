import{default as t}from"../entry/_page.svelte.47daf533.js";export{t as component};
