import{default as t}from"../entry/error.svelte.e6bf68c6.js";export{t as component};
