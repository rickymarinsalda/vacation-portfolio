import{default as t}from"../entry/_page.svelte.5d6b133d.js";export{t as component};
