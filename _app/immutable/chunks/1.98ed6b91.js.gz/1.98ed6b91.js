import{default as t}from"../entry/error.svelte.686675b2.js";export{t as component};
