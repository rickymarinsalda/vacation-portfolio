import{default as t}from"../entry/_page.svelte.aa84a285.js";export{t as component};
