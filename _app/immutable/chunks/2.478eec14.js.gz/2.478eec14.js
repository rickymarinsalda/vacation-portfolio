import{default as t}from"../entry/_page.svelte.4fa56c83.js";export{t as component};
