import{default as t}from"../entry/error.svelte.1334b79a.js";export{t as component};
