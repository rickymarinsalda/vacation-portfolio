import{default as t}from"../entry/error.svelte.85cbe3b7.js";export{t as component};
