import{default as t}from"../entry/_page.svelte.546fb39c.js";export{t as component};
