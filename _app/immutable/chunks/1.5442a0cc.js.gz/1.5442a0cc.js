import{default as t}from"../entry/error.svelte.e88eb226.js";export{t as component};
