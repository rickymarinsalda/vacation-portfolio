import{default as t}from"../entry/_page.svelte.951797aa.js";export{t as component};
