import{default as t}from"../entry/error.svelte.62c79aac.js";export{t as component};
