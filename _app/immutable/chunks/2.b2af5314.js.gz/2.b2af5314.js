import{default as t}from"../entry/_page.svelte.78945d82.js";export{t as component};
