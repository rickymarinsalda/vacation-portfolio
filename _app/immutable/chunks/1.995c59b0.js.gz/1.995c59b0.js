import{default as t}from"../entry/error.svelte.c5167ba2.js";export{t as component};
