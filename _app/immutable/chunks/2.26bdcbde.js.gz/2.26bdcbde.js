import{default as t}from"../entry/_page.svelte.cbf0689d.js";export{t as component};
