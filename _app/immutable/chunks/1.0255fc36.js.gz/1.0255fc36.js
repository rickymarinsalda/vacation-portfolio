import{default as t}from"../entry/error.svelte.7d10e742.js";export{t as component};
