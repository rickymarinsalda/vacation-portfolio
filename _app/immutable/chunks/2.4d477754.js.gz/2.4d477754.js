import{default as t}from"../entry/_page.svelte.27d6d1da.js";export{t as component};
