import{default as t}from"../entry/error.svelte.64cff6ed.js";export{t as component};
