import{default as t}from"../entry/error.svelte.cd3fe9a7.js";export{t as component};
