import{default as t}from"../entry/error.svelte.3ed33f13.js";export{t as component};
