import{default as t}from"../entry/error.svelte.92685bc0.js";export{t as component};
