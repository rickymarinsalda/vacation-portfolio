import{default as t}from"../entry/error.svelte.15f1fa16.js";export{t as component};
