import{default as t}from"../entry/_page.svelte.5052740f.js";export{t as component};
