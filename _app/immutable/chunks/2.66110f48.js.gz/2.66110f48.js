import{default as t}from"../entry/_page.svelte.9d0b0dcc.js";export{t as component};
