import{default as t}from"../entry/error.svelte.871c10f0.js";export{t as component};
