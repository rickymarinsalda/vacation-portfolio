import{default as t}from"../entry/_page.svelte.89de5479.js";export{t as component};
