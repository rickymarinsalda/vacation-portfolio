import{default as t}from"../entry/error.svelte.d193c17b.js";export{t as component};
